package lia.kitty;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.entity.LivingEntity;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class KittyLia implements ClientModInitializer {
    static boolean shiftWas;

    @Override public void onInitializeClient() {
        ModuleManager.init();
        Config.load();
        ClientTickEvents.END_CLIENT_TICK.register(KittyLia::tick);
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClient() && entity instanceof LivingEntity t) Swap.forAttack(t, false);
            return ActionResult.PASS;
        });
        HudElementRegistry.addLast(Identifier.of("kittylia", "hud"), HudRender::render);
        // On-screen button for phones (no Right Shift needed) on title + pause menu
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen instanceof TitleScreen || screen instanceof GameMenuScreen)
                Screens.getButtons(screen).add(ButtonWidget.builder(Text.literal("kitty.lia"), b -> client.setScreen(new KittyScreen())).dimensions(4, 4, 64, 20).build());
        });
    }

    static void tick(MinecraftClient mc) {
        long h = mc.getWindow().getHandle();
        boolean sh = GLFW.glfwGetKey(h, GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
        if (sh && !shiftWas) {
            if (mc.currentScreen instanceof KittyScreen) mc.setScreen(null);
            else if (!(mc.currentScreen instanceof ChatScreen)) mc.setScreen(new KittyScreen());
        }
        shiftWas = sh;
        Swap.tick();
        if (mc.player == null || mc.world == null) return;
        for (Module m : ModuleManager.all) if (m.enabled) m.onTick();
    }
}

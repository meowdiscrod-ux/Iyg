package lia.kitty;
import java.io.*;
import java.nio.file.*;
import java.util.Properties;
import net.fabricmc.loader.api.FabricLoader;
public final class Config {
    static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("kittylia.properties"); }
    public static void save() {
        try {
            Properties p = new Properties();
            p.setProperty("theme", String.valueOf(Theme.index));
            for (Module m : ModuleManager.all) {
                if (!m.name.equals("Key Pearl")) p.setProperty(m.name + ".on", String.valueOf(m.enabled));
                for (Setting s : m.settings) p.setProperty(m.name + "." + s.name, String.valueOf(s.value));
            }
            try (OutputStream o = Files.newOutputStream(file())) { p.store(o, "kitty.lia"); }
        } catch (Exception ignored) {}
    }
    public static void load() {
        try {
            if (!Files.exists(file())) return;
            Properties p = new Properties();
            try (InputStream i = Files.newInputStream(file())) { p.load(i); }
            Theme.index = Integer.parseInt(p.getProperty("theme", "0")) % Theme.COLS.length;
            for (Module m : ModuleManager.all) {
                m.enabled = Boolean.parseBoolean(p.getProperty(m.name + ".on", "false"));
                for (Setting s : m.settings) {
                    String v = p.getProperty(m.name + "." + s.name);
                    if (v != null) s.value = Double.parseDouble(v);
                }
            }
        } catch (Exception ignored) {}
    }
}

package lia.kitty;
import java.util.*;
import net.minecraft.client.MinecraftClient;
public abstract class Module {
    protected static final MinecraftClient mc = MinecraftClient.getInstance();
    public final String name; public final Category cat;
    public boolean enabled, open;
    public final List<Setting> settings = new ArrayList<>();
    protected Module(String n, Category c) { name = n; cat = c; }
    protected Setting add(String n, double v, double mn, double mx) { Setting s = new Setting(n, v, mn, mx); settings.add(s); return s; }
    public void toggle() { enabled = !enabled; if (enabled) onEnable(); else onDisable(); }
    public void onEnable() {}
    public void onDisable() {}
    public void onTick() {}
}

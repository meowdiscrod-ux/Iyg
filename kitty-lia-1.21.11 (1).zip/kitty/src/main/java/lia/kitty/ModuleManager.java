package lia.kitty;
import java.util.*;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.MathHelper;

public final class ModuleManager {
    public static final List<Module> all = new ArrayList<>();

    public static void init() {
        // ---- Combat (order requested) ----
        all.add(new TriggerBot());
        all.add(new AimAssist());
        all.add(new AutoMace());
        all.add(new MaceSwap());
        all.add(new BreachSwap());
        all.add(new SpearLungeAuto());
        all.add(new SpearReach());
        // ---- Misc ----
        all.add(new AutoTool());
        all.add(new KeyPearl());
        // ---- Movement ----
        all.add(new Sprint());
        // ---- Visual ----
        all.add(new Hud());
    }
    public static List<Module> of(Category c) { List<Module> l = new ArrayList<>(); for (Module m : all) if (m.cat == c) l.add(m); return l; }
    public static boolean on(String n) { for (Module m : all) if (m.name.equals(n)) return m.enabled; return false; }

    // Fires on whatever you are looking at. Goes through the attack hook, so Mace Swap / Breach Swap apply.
    static class TriggerBot extends Module {
        final Setting cd = add("Cooldown", 0.92, 0.5, 1.0);
        TriggerBot() { super("Trigger Bot", Category.COMBAT); }
        @Override public void onTick() {
            if (mc.currentScreen != null) return;
            if (mc.crosshairTarget instanceof EntityHitResult r && r.getEntity() instanceof PlayerEntity t && t.isAlive()) {
                if (mc.player.getAttackCooldownProgress(0.5f) >= cd.value) Combat.attack(t);
            }
        }
    }

    static class AimAssist extends Module {
        final Setting range = add("Range", 4.5, 2, 8), fov = add("FOV", 90, 20, 360), speed = add("Speed", 0.25, 0.05, 1.0);
        AimAssist() { super("Aim Assist", Category.COMBAT); }
        @Override public void onTick() {
            if (mc.currentScreen != null || !mc.options.attackKey.isPressed()) return;
            PlayerEntity t = Combat.nearest(range.value, fov.value);
            if (t == null) return;
            float dy = MathHelper.wrapDegrees(Combat.yawTo(t) - mc.player.getYaw());
            float dp = Combat.pitchTo(t) - mc.player.getPitch();
            mc.player.setYaw(mc.player.getYaw() + dy * (float) speed.value);
            mc.player.setPitch(MathHelper.clamp(mc.player.getPitch() + dp * (float) speed.value, -90f, 90f));
        }
    }

    // Falling + target in reach -> mace in hand -> hit.
    static class AutoMace extends Module {
        final Setting reach = add("Reach", 3.0, 2, 4), fall = add("Min fall", 1.6, 1.5, 6), delay = add("Delay", 10, 2, 30);
        int t;
        AutoMace() { super("Auto Mace", Category.COMBAT); }
        @Override public void onTick() {
            t++;
            if (mc.currentScreen != null || mc.player.isOnGround() || mc.player.fallDistance < fall.value || t < delay.value) return;
            PlayerEntity target = Combat.nearest(reach.value, 360);
            if (target == null || Swap.find(Swap::isMace) < 0) return;
            Swap.forAttack(target, true);
            if (Swap.isMace(mc.player.getMainHandStack())) { Combat.attack(target); t = 0; }
        }
    }

    // Swaps to the mace for any hit you make while falling (manual, Trigger Bot or Auto Mace).
    static class MaceSwap extends Module { MaceSwap() { super("Mace Swap", Category.COMBAT); } }

    // Not falling and the target wears armor -> swaps to a Breach mace.
    static class BreachSwap extends Module { BreachSwap() { super("Breach Swap", Category.COMBAT); } }

    static class SpearLungeAuto extends Module {
        final Setting range = add("Range", 6.0, 3, 8), delay = add("Delay", 14, 4, 40);
        int t;
        SpearLungeAuto() { super("Spear Lunge Auto", Category.COMBAT); }
        @Override public void onTick() {
            t++;
            if (mc.currentScreen != null || !mc.player.isSprinting() || t < delay.value) return;
            int s = Swap.find(Swap::isSpear); if (s < 0) return;
            PlayerEntity target = Combat.nearest(range.value, 120);
            if (target == null || Combat.dist(target) < 2.5) return;
            Swap.select(s); Combat.attack(target); t = 0;
        }
    }

    static class SpearReach extends Module {
        final Setting range = add("Range", 4.5, 3, 6), delay = add("Delay", 12, 4, 40);
        int t;
        SpearReach() { super("Spear Reach", Category.COMBAT); }
        @Override public void onTick() {
            t++;
            if (mc.currentScreen != null || t < delay.value) return;
            int s = Swap.find(Swap::isSpear); if (s < 0) return;
            PlayerEntity target = Combat.nearest(range.value, 90);
            if (target == null || Combat.dist(target) <= 3.0) return;
            Swap.select(s); Combat.attack(target); t = 0;
        }
    }

    static class AutoTool extends Module {
        AutoTool() { super("Auto Tool", Category.MISC); }
        @Override public void onTick() {
            if (mc.currentScreen != null || !mc.options.attackKey.isPressed()) return;
            if (!(mc.crosshairTarget instanceof BlockHitResult r)) return;
            BlockState st = mc.world.getBlockState(r.getBlockPos());
            var inv = mc.player.getInventory(); int best = inv.getSelectedSlot(); float bs = inv.getStack(best).getMiningSpeedMultiplier(st);
            for (int i = 0; i < 9; i++) { float s = inv.getStack(i).getMiningSpeedMultiplier(st); if (s > bs) { bs = s; best = i; } }
            inv.setSelectedSlot(best);
        }
    }

    // Toggle it on = throws a pearl, then turns itself off.
    static class KeyPearl extends Module {
        KeyPearl() { super("Key Pearl", Category.MISC); }
        @Override public void onEnable() {
            if (mc.player != null) {
                int s = Swap.find(x -> x.isOf(Items.ENDER_PEARL));
                if (s >= 0) { Swap.select(s); mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND); mc.player.swingHand(Hand.MAIN_HAND); }
            }
            enabled = false;
        }
    }

    static class Sprint extends Module {
        Sprint() { super("Sprint", Category.MOVEMENT); }
        @Override public void onTick() {
            var p = mc.player;
            if (mc.options.forwardKey.isPressed() && !p.isSneaking() && !p.horizontalCollision && p.getHungerManager().getFoodLevel() > 6) p.setSprinting(true);
        }
    }

    static class Hud extends Module { Hud() { super("Hud", Category.VISUAL); } }
}

package lia.kitty;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.*;

public final class Combat {
    static final MinecraftClient mc = MinecraftClient.getInstance();

    public static double dist(PlayerEntity e) {
        Vec3d eye = mc.player.getEyePos(); Box b = e.getBoundingBox();
        double x = MathHelper.clamp(eye.x, b.minX, b.maxX), y = MathHelper.clamp(eye.y, b.minY, b.maxY), z = MathHelper.clamp(eye.z, b.minZ, b.maxZ);
        return eye.distanceTo(new Vec3d(x, y, z));
    }
    public static float yawTo(PlayerEntity e) {
        Vec3d c = e.getBoundingBox().getCenter(); Vec3d eye = mc.player.getEyePos();
        return (float) (Math.toDegrees(Math.atan2(c.z - eye.z, c.x - eye.x)) - 90.0);
    }
    public static float pitchTo(PlayerEntity e) {
        Vec3d c = e.getBoundingBox().getCenter(); Vec3d eye = mc.player.getEyePos();
        double h = Math.sqrt((c.x - eye.x) * (c.x - eye.x) + (c.z - eye.z) * (c.z - eye.z));
        return (float) -Math.toDegrees(Math.atan2(c.y - eye.y, h));
    }
    /** Nearest living player inside range and inside the fov cone. */
    public static PlayerEntity nearest(double range, double fov) {
        PlayerEntity best = null; double bd = Double.MAX_VALUE;
        for (PlayerEntity e : mc.world.getPlayers()) {
            if (e == mc.player || !e.isAlive() || e.isSpectator()) continue;
            double d = dist(e);
            if (d > range) continue;
            if (fov < 360 && Math.abs(MathHelper.wrapDegrees(yawTo(e) - mc.player.getYaw())) > fov / 2.0) continue;
            if (d < bd) { bd = d; best = e; }
        }
        return best;
    }
    public static void attack(PlayerEntity t) {
        mc.interactionManager.attackEntity(mc.player, t);
        mc.player.swingHand(Hand.MAIN_HAND);
    }
}

package lia.kitty;
public enum Category {
    COMBAT("Combat"), MISC("Misc"), MOVEMENT("Movement"), VISUAL("Visual");
    public final String label;
    Category(String l) { label = l; }
}

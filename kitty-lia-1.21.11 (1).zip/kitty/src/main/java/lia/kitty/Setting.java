package lia.kitty;
public class Setting {
    public final String name; public double value; public final double min, max;
    public Setting(String n, double v, double mn, double mx) { name = n; value = v; min = mn; max = mx; }
}

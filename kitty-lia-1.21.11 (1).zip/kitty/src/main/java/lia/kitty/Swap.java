package lia.kitty;
import java.util.function.Predicate;
import net.minecraft.client.MinecraftClient;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKeys;

public final class Swap {
    static final MinecraftClient mc = MinecraftClient.getInstance();
    static int back = -1, wait = 0;

    public static boolean isMace(ItemStack s) { return s.isOf(Items.MACE); }
    public static boolean isSpear(ItemStack s) { return Registries.ITEM.getId(s.getItem()).getPath().endsWith("_spear"); }
    public static boolean hasBreach(ItemStack s) {
        try {
            var reg = mc.world.getRegistryManager().getOrThrow(RegistryKeys.ENCHANTMENT);
            return EnchantmentHelper.getLevel(reg.getOrThrow(Enchantments.BREACH), s) > 0;
        } catch (Throwable t) { return false; }
    }
    public static int find(Predicate<ItemStack> f) {
        for (int i = 0; i < 9; i++) if (f.test(mc.player.getInventory().getStack(i))) return i;
        return -1;
    }
    public static void select(int slot) {
        if (slot < 0 || slot > 8) return;
        int cur = mc.player.getInventory().getSelectedSlot();
        if (slot == cur) return;
        if (back < 0) back = cur;
        mc.player.getInventory().setSelectedSlot(slot);
        wait = 2;
    }
    public static void tick() {
        if (mc.player == null) { back = -1; return; }
        if (back >= 0 && --wait <= 0) { mc.player.getInventory().setSelectedSlot(back); back = -1; }
    }
    public static boolean falling() { return !mc.player.isOnGround() && mc.player.fallDistance > 1.5; }

    /** Called right before any attack on a living entity (manual, Trigger Bot, Auto Mace). */
    public static void forAttack(LivingEntity t, boolean forceMace) {
        if (mc.player == null) return;
        boolean fall = falling();
        if (fall && (forceMace || ModuleManager.on("Mace Swap"))) {
            int s = find(x -> isMace(x) && !hasBreach(x));
            if (s < 0) s = find(Swap::isMace);
            if (s >= 0) { select(s); return; }
        }
        if (!fall && ModuleManager.on("Breach Swap") && t.getArmor() > 0) {
            int s = find(x -> isMace(x) && hasBreach(x));
            if (s >= 0) select(s);
        }
    }
}

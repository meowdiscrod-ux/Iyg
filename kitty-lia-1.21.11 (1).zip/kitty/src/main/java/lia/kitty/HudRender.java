package lia.kitty;
import java.util.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

public final class HudRender {
    public static void render(DrawContext c, RenderTickCounter tick) {
        if (!ModuleManager.on("Hud")) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden) return;
        var tr = mc.textRenderer; int acc = Theme.accent();
        c.fill(4, 4, 6 + tr.getWidth("kitty.lia") + 6, 17, 0x90000000);
        c.fill(4, 4, 6, 17, acc);
        c.drawText(tr, "kitty.lia", 10, 7, acc, false);
        List<String> names = new ArrayList<>();
        for (Module m : ModuleManager.all) if (m.enabled && m.cat != Category.VISUAL) names.add(m.name);
        names.sort((a, b) -> tr.getWidth(b) - tr.getWidth(a));
        int w = c.getScaledWindowWidth(), y = 4;
        for (String n : names) {
            int tw = tr.getWidth(n);
            c.fill(w - tw - 8, y, w - 2, y + 11, 0x80000000);
            c.fill(w - 2, y, w, y + 11, acc);
            c.drawText(tr, n, w - tw - 5, y + 2, acc, false);
            y += 11;
        }
    }
}

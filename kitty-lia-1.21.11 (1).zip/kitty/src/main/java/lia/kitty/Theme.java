package lia.kitty;
public final class Theme {
    public static final String[] NAMES = {"Kitty", "Ocean", "Mint", "Ember", "Violet"};
    public static final int[] COLS = {0xFFFF7AC8, 0xFF4DA3FF, 0xFF4DE0B0, 0xFFFF8A4D, 0xFFA78BFA};
    public static int index = 0;
    public static int accent() { return COLS[index]; }
    public static String name() { return NAMES[index]; }
    public static void next() { index = (index + 1) % COLS.length; }
}

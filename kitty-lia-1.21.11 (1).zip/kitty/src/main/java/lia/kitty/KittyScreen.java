package lia.kitty;
import java.util.List;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/** Original layout: left tab rail, card rows with pill toggles, click a name to expand its sliders. */
public class KittyScreen extends Screen {
    static final int W = 400, H = 250, RAIL = 96, ROW = 26, SL = 22;
    Category sel = Category.COMBAT;
    int scroll;
    boolean wasDown;
    Setting dragging;

    public KittyScreen() { super(Text.literal("kitty.lia")); }
    @Override public boolean shouldPause() { return false; }
    @Override public void removed() { Config.save(); }
    @Override public boolean mouseScrolled(double x, double y, double hx, double vy) { scroll -= (int) (vy * 16); return true; }

    boolean in(int mx, int my, int x, int y, int w, int h) { return mx >= x && mx < x + w && my >= y && my < y + h; }

    @Override public void render(DrawContext c, int mx, int my, float delta) {
        boolean down = GLFW.glfwGetMouseButton(client.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean click = down && !wasDown; wasDown = down;
        if (!down) dragging = null;

        int acc = Theme.accent();
        int x = (width - W) / 2, y = (height - H) / 2;
        c.fill(0, 0, width, height, 0x70000000);
        c.fill(x, y, x + W, y + H, 0xF2121016);
        c.fill(x, y, x + RAIL, y + H, 0xFF0C0A10);
        c.fill(x, y, x + W, y + 2, acc);

        c.drawText(textRenderer, "kitty.lia", x + 12, y + 12, acc, true);
        c.drawText(textRenderer, "1.21.11", x + 12, y + 24, 0xFF77727F, false);

        // tabs
        int i = 0;
        for (Category cat : Category.values()) {
            int ty = y + 46 + i * 28; boolean s = cat == sel, hov = in(mx, my, x, ty, RAIL, 24);
            if (s) { c.fill(x, ty, x + RAIL, ty + 24, 0xFF1C1822); c.fill(x, ty, x + 3, ty + 24, acc); }
            else if (hov) c.fill(x, ty, x + RAIL, ty + 24, 0xFF15121A);
            c.drawText(textRenderer, cat.label, x + 16, ty + 8, s ? 0xFFFFFFFF : 0xFF9A94A6, false);
            if (hov && click) { sel = cat; scroll = 0; }
            i++;
        }
        // theme chip
        int cy = y + H - 30; boolean chov = in(mx, my, x + 10, cy, RAIL - 20, 20);
        c.fill(x + 10, cy, x + RAIL - 10, cy + 20, chov ? 0xFF241F2C : 0xFF1A1620);
        c.fill(x + 14, cy + 6, x + 22, cy + 14, acc);
        c.drawText(textRenderer, Theme.name(), x + 28, cy + 6, 0xFFE8E4EE, false);
        if (chov && click) { Theme.next(); }

        // content
        int cx = x + RAIL + 10, cw = W - RAIL - 20, top = y + 10, bottom = y + H - 10;
        List<Module> mods = ModuleManager.of(sel);
        int total = 0;
        for (Module m : mods) total += ROW + 4 + (m.open ? m.settings.size() * SL + 4 : 0);
        scroll = Math.max(0, Math.min(scroll, Math.max(0, total - (bottom - top))));

        c.enableScissor(cx, top, cx + cw, bottom);
        int ry = top - scroll;
        boolean inside = in(mx, my, cx, top, cw, bottom - top);
        for (Module m : mods) {
            boolean hov = inside && in(mx, my, cx, ry, cw, ROW);
            c.fill(cx, ry, cx + cw, ry + ROW, hov ? 0xFF211D29 : 0xFF1A1620);
            if (m.enabled) c.fill(cx, ry, cx + 3, ry + ROW, acc);
            c.drawText(textRenderer, m.name, cx + 12, ry + 9, m.enabled ? 0xFFFFFFFF : 0xFFA9A3B5, false);
            if (!m.settings.isEmpty()) c.drawText(textRenderer, m.open ? "-" : "+", cx + cw - 52, ry + 9, 0xFF77727F, false);
            // pill
            int px = cx + cw - 34, py = ry + 7;
            c.fill(px, py, px + 26, py + 12, m.enabled ? acc : 0xFF2C2735);
            int kx = m.enabled ? px + 15 : px + 2;
            c.fill(kx, py + 2, kx + 9, py + 10, 0xFFFFFFFF);
            if (inside && click) {
                if (in(mx, my, px - 4, ry, 38, ROW)) m.toggle();
                else if (in(mx, my, cx, ry, cw, ROW) && !m.settings.isEmpty()) m.open = !m.open;
            }
            ry += ROW + 4;
            if (m.open) {
                for (Setting s : m.settings) {
                    int bx = cx + 12, bw = cw - 24, by = ry + 14;
                    double f = (s.value - s.min) / (s.max - s.min);
                    c.drawText(textRenderer, s.name, bx, ry + 2, 0xFF9A94A6, false);
                    String v = String.format("%.2f", s.value);
                    c.drawText(textRenderer, v, bx + bw - textRenderer.getWidth(v), ry + 2, 0xFFE8E4EE, false);
                    c.fill(bx, by, bx + bw, by + 4, 0xFF2C2735);
                    c.fill(bx, by, bx + (int) (bw * f), by + 4, acc);
                    c.fill(bx + (int) (bw * f) - 2, by - 2, bx + (int) (bw * f) + 2, by + 6, 0xFFFFFFFF);
                    if (inside && click && in(mx, my, bx - 2, by - 4, bw + 4, 12)) dragging = s;
                    if (dragging == s) {
                        double nf = Math.max(0, Math.min(1, (mx - bx) / (double) bw));
                        s.value = Math.round((s.min + (s.max - s.min) * nf) * 100.0) / 100.0;
                    }
                    ry += SL;
                }
                ry += 4;
            }
        }
        c.disableScissor();
    }
}
